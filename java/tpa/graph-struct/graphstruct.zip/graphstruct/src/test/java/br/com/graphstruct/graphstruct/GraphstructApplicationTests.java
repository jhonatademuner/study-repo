package br.com.graphstruct.graphstruct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GraphstructApplicationTests {

	@Test
	void contextLoads() {
	}

}
