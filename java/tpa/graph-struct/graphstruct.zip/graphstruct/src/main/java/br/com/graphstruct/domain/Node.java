package br.com.graphstruct.domain;

public interface Node<T> {

	T getValue();

	void setValue(T value);

}
