package br.com.graphstruct.domain;

public interface City {

	String getName();

	void setName(String name);

	String getState();

	void setState(String state);

	String getCountry();

	void setCountry(String country);

	int getPopulation();

	void setPopulation(int population);

}
